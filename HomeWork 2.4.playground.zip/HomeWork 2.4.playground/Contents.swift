//import Foundation
//
//protocol Animal {
//    func makeSound()
//}
//
//protocol Walkable {
//    func walk()
//}
//
//protocol Swimmable {
//    func swim()
//}
//
//protocol Flyable {
//    func fly()
//}
//
//struct Cow: Animal, Walkable {
//    func makeSound() {
//        print("Muu")
//    }
//    
//    func walk() {
//        print("Cow is walking.")
//    }
//}
//
//struct Dog: Animal, Walkable {
//    func makeSound() {
//        print("Gaf Gaf")
//    }
//    
//    func walk() {
//        print("Dog is walking.")
//    }
//}
//
//struct Shark: Animal, Swimmable {
//    func makeSound() {
//        print("...")
//    }
//    
//    func swim() {
//        print("Shark is swimming.")
//    }
//}
//
//struct Bird: Animal, Flyable {
//    func makeSound() {
//        print("Chic chirik")
//    }
//    
//    func fly() {
//        print("Bird is flying.")
//    }
//}
//
//let cow = Cow()
//cow.makeSound()
//cow.walk()
//
//let dog = Dog()
//dog.makeSound()
//dog.walk()
//
//let shark = Shark()
//shark.makeSound()
//shark.swim()
//
//let bird = Bird()
//bird.makeSound()
//bird.fly()
//



import Foundation

enum CardValue: Int {
    case ace = 1, two, three, four, five, six, seven, eight, nine, ten, jack, queen, king
}

enum Guess: String {
    case higher = "H", lower = "L"
}

struct Card {
    let value: CardValue
}

class Game {
    var deck: [Card] = []
    var playerMoney: Int = 250
    let betAmount: Int = 25
    
    func start() {
        print("Welcome to HiLo!")
        
        while playerMoney >= betAmount {
            resetDeck()
            var previousCard: Card?
            
            while let currentCard = drawCard() {
                print("Current card: \(currentCard.value.rawValue)")
                
                if let previous = previousCard, !isSameValue(card1: currentCard, card2: previous) {
                    let playerGuess = getPlayerGuess()
                    let computerGuess = getRandomGuess()
                    
                    print("Computer's guess: \(computerGuess.rawValue)")
                    
                    if playerGuess == computerGuess {
                        print("Correct guess!")
                        
                        if isHigherValue(card1: currentCard, card2: previous) {
                            playerMoney += betAmount
                            print("You win!")
                        } else {
                            playerMoney -= betAmount
                            print("You lose!")
                        }
                    } else {
                        print("Incorrect guess!")
                        playerMoney -= betAmount
                        break
                    }
                }
                
                previousCard = currentCard
            }
            
            print("Game over. Your money: $\(playerMoney)")
        }
        
        print("Out of money. Game over!")
    }
    
    func resetDeck() {
        deck.removeAll()
        
        for value in CardValue.ace.rawValue...CardValue.king.rawValue {
            if let cardValue = CardValue(rawValue: value) {
                deck.append(Card(value: cardValue))
            }
        }
        
        deck.shuffle()
    }
    
    func drawCard() -> Card? {
        guard !deck.isEmpty else {
            return nil
        }
        
        return deck.removeLast()
    }
    
    func getPlayerGuess() -> Guess {
        while true {
            print("Enter your guess (H for higher, L for lower):")
            
            if let input = readLine()?.uppercased(), let guess = Guess(rawValue: input) {
                return guess
            }
            
            print("Invalid input. Please try again.")
        }
    }
    
    func getRandomGuess() -> Guess {
        return Bool.random() ? .higher : .lower
    }
    
    func isSameValue(card1: Card, card2: Card) -> Bool {
        return card1.value == card2.value
    }
    
    func isHigherValue(card1: Card, card2: Card) -> Bool {
        return card1.value.rawValue > card2.value.rawValue
    }
}

let game = Game()
game.start()
